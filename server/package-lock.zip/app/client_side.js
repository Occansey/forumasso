sessionStorage.setItem('token',token)
//or
localStorage.setItem('token',token)

const token=sessionStorage.getItem('token',token)
const token=sessionStorage.getItem('token',token)


ùfetch('';{

})