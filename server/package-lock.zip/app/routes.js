const express = require('express');
const { ObjectId } = require('mongodb');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const cors = require('cors');

router.use(cors());
router.use(express.json());
const MongoClient = require('mongodb').MongoClient;
const mongoURL = 'mongodb+srv://maxwelloccansey:amineMaxwell75%3F@organizasso.oqwz5xd.mongodb.net/organizasso';
const dbName = 'organizasso';
let postsCollection="";
let messagesCollection ='';
let usersCollection='';

MongoClient.connect(mongoURL)
    .then(client => {
        console.log('Connected to MongoDB');
        const db = client.db(dbName);
        postsCollection = db.collection('posts');
        usersCollection= db.collection('users');
        messagesCollection=db.collection('messages');
    })
    .catch(error => {
        console.error('Error connecting to MongoDB:', error);
    });


// // // // // // // // // // // // POSTS
// GET ALL POSTS 
router.get('/posts/private', async (req, res) => {
    try {
        const posts = await postsCollection.find({ privMessage: true }).toArray();
        res.json(posts);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

router.get('/posts/public', async (req, res) => {
    try {
        const posts = await postsCollection.find({ privMessage: false }).toArray();
        res.json(posts);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// GET MESSAGES BASED ON A QUERY 
router.get('/posts/search', async (req, res) => {
    const { title, content } = req.query; 
    try {
        let query = {};
        if (title) {
            query.title = { $regex: title, $options: 'i' };
        }
        if (content) {
            query.content = { $regex: content, $options: 'i' }; 
        }
        const posts = await postsCollection.find(query).toArray();
        
        res.json(posts);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// // GET a specific post by ID //inutile
// router.get('/posts/:id', async (req, res) => {
//     try {
//         const post = await postsCollection.findOne({ _id: ObjectId(req.params.id) });
//         if (!post) {
//             res.status(404).json({ message: 'Post not found' });
//         } else {
//             res.json(post);
//         }
//     } catch (error) {
//         res.status(500).json({ message: error.message });
//     }
// });

// Create a new post
router.post('/posts/private', async (req, res) => {
    const { title, content } = req.body; // Destructuring req.body to extract title and content
    if (!title || !content) {
        res.status(400).json({ message: 'Title and content are required' });
        return;
    }
    try {
        const result = await postsCollection.insertOne({ title , content });
        res.status(201).json(req.body);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

router.post('/posts/public', async (req, res) => {
    const { title, content } = req.body; // Destructuring req.body to extract title and content
    if (!title || !content) {
        res.status(400).json({ message: 'Title and content are required' });
        return;
    }
    try {
        const result = await postsCollection.insertOne({ title , content });
        res.status(201).json(req.body);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});


// Delete a post by ID
router.delete('/posts/:id', async (req, res) => {
    const postId=new ObjectId(req.params.id)
    try {
        const result = await postsCollection.deleteOne({ _id: postId });
        if (result.deletedCount === 0) {
            res.status(404).json({ message: 'Post already deleted or not found' });
        } else {
            res.status(204).send();
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});


// // // // // // // // // // // // USERS
// SIGN UP
// Register endpoint
router.post('/register', async (req, res) => {
    try {
        const { username, email, password, userPosts } = req.body;

        if (!username || !email || !password) return res.status(400).json({ message: 'Username, email, and password are required' });

        const existingUser = await usersCollection.findOne({ $or: [{ username }, { email }] });
        if (existingUser) return res.status(400).json({ message: 'Username or email already exists' });
        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = {
            username:username,
            email:email,
            password: hashedPassword, // Store hashed password
            member: false, // Assuming default member status is false
            admin: false, // Assuming default admin status is false
            date: new Date(), // Timestamp for registration date
            connected: true, // Assuming user is connected upon registration
            posts: [], // Array to store linked post IDs
            followers:[]
        };
        const result = await usersCollection.insertOne(newUser);
        if (userPosts && Array.isArray(userPosts)) {
            const postIds = [];
            for (const post of userPosts) {
                const insertedPost = await postsCollection.insertOne(post);
                postIds.push(insertedPost.insertedId);
            }
            await usersCollection.updateOne({ _id: result.insertedId }, { $set: { posts: postIds } });
        }
        res.status(201).json({ message: 'User registered successfully'});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
  
        if (!email || !password) return res.status(400).json({ message: 'Email and password are required' });
  
        const user = await usersCollection.findOne({ email: email });
        if (!user) return res.status(404).json({ message: 'User not found' });
  
        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) return res.status(401).json({ message: 'Invalid password' });
  
        const token = generateToken(user);
        res.status(200).json({ message: 'Logged in successfully', user, token });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
  });



router.get('/messages/:userId', async (req, res) => {
    muid=req.params.id
    const mid=new ObjectId(muid)
    try {
        const messages = await messagesCollection.find({ userId: muid}).toArray();
        res.json(messages);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});


router.post('/messages/:id', async (req, res) => {
  const uid=req.params.id
  const userId  =new ObjectId(uid)
  console.log('POST MESSAGES ID')
  const { text } = req.body;
  const user = await usersCollection.findOne({ _id:userId});
  if (!user) return res.status(404).json({ message: 'User not found' });
  if (!text) return res.status(400).json({ message: 'Text is required' });
  const newMessage = {
    id: new Date().getTime(),
    text,
    userId: uid,
    privMessage: false
  };
    try {
        await messagesCollection.insertOne(newMessage);
        res.status(201).json(req.body);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

router.post('/messages/public/:id', async (req, res) => {
    const uid=req.params.id
    const userId  =new ObjectId(uid)
    console.log('POST MESSAGES ID')
    const { text } = req.body;
    const user = await usersCollection.findOne({ _id:userId});
    if (!user) return res.status(404).json({ message: 'User not found' });
    if (!text) return res.status(400).json({ message: 'Text is required' });
    const newMessage = {
      id: new Date().getTime(),
      text,
      userId: uid,
      privMessage: true,
    };
      try {
          await messagesCollection.insertOne(newMessage);
          res.status(201).json(req.body);
      } catch (error) {
          res.status(500).json({ message: error.message });
      }
  });

module.exports = router;

// // // // // // // // // // // // Essential fonctions and consts
function generateToken(user) {
    const payload =
    {
        id: user._id,
        username: user.username,
        email: user.email,
        member: user.member,
        admin: user.admin,
        connected: user.connected,
        date: user.date,
    };
    const secretKey = crypto.randomBytes(32).toString('hex');
    const options = { expiresIn: '1h' };
    return jwt.sign(payload, secretKey, options);
}


module.exports = router;
